﻿Class MainWindow
    Private Sub Generate0(sender As Object, e As RoutedEventArgs)
        output0.Text = head.Text + ("Text1") + text.Text + text1.Text + color.Text + color1.Text + bold.Text + bold1.Text + italic.Text + italic1.Text + underlined.Text + underline1.Text + strikethrough.Text + strikethrough1.Text + obfuscated.Text + obfuscated1.Text + clickevent.Text + clickevent1.Text + end0.Text + ("Text2") + text.Text + text2.Text + color.Text + color2.Text + bold.Text + bold2.Text + italic.Text + italic2.Text + underlined.Text + underline2.Text + strikethrough.Text + strikethrough2.Text + obfuscated.Text + obfuscated2.Text + clickevent.Text + clickevent2.Text + end0.Text + ("Text3") + text.Text + text3.Text + color.Text + color3.Text + bold.Text + bold3.Text + italic.Text + italic3.Text + underlined.Text + underline3.Text + strikethrough.Text + strikethrough3.Text + obfuscated.Text + obfuscated3.Text + clickevent.Text + clickevent3.Text + end0.Text + ("Text4") + text.Text + text4.Text + color.Text + color4.Text + bold.Text + bold4.Text + italic.Text + italic4.Text + underlined.Text + underline4.Text + strikethrough.Text + strikethrough4.Text + obfuscated.Text + obfuscated4.Text + clickevent.Text + clickevent4.Text + end0.Text + [end].Text
        status0.Text = (" Code generated successfully!")
    End Sub

    Private Sub Copy0(sender As Object, e As RoutedEventArgs)
        Clipboard.Clear()
        Clipboard.SetText(output0.Text)
        status0.Text = (" Code copied successfully!")
    End Sub

    Private Sub outputreset0(sender As Object, e As RoutedEventArgs) Handles text1.GotFocus, text2.GotFocus, text3.GotFocus, text4.GotFocus, color1.GotFocus, color2.GotFocus, color3.GotFocus, color4.GotFocus, bold1c.GotFocus, bold2c.GotFocus, bold3c.GotFocus, bold4c.GotFocus, italic1c.GotFocus, italic2c.GotFocus, italic3c.GotFocus, italic4c.GotFocus, underline1c.GotFocus, underline2c.GotFocus, underline3c.GotFocus, underline4c.GotFocus, strikethrough1c.GotFocus, strikethrough2c.GotFocus, strikethrough3c.GotFocus, strikethrough4c.GotFocus, obfuscated1c.GotFocus, obfuscated2c.GotFocus, obfuscated3c.GotFocus, obfuscated4c.GotFocus, clickevent1.GotFocus, clickevent2.GotFocus, clickevent3.GotFocus, clickevent4.GotFocus
        status0.Text = (" Ready (note: some text effects cannot be displayed in the Preview tab)")
    End Sub

    Private Sub b1c(sender As Object, e As RoutedEventArgs) Handles bold1c.Checked
        bold1ds.Text = ("bold")
    End Sub

    Private Sub b1uc(sender As Object, e As RoutedEventArgs) Handles bold1c.Unchecked
        bold1ds.Text = ("")
    End Sub

    Private Sub b2c(sender As Object, e As RoutedEventArgs) Handles bold2c.Checked
        bold2ds.Text = ("bold")
    End Sub

    Private Sub b2uc(sender As Object, e As RoutedEventArgs) Handles bold2c.Unchecked
        bold2ds.Text = ("")
    End Sub

    Private Sub b3c(sender As Object, e As RoutedEventArgs) Handles bold3c.Checked
        bold3ds.Text = ("bold")
    End Sub

    Private Sub b3uc(sender As Object, e As RoutedEventArgs) Handles bold3c.Unchecked
        bold3ds.Text = ("")
    End Sub

    Private Sub b4c(sender As Object, e As RoutedEventArgs) Handles bold4c.Checked
        bold4ds.Text = ("bold")
    End Sub

    Private Sub b4uc(sender As Object, e As RoutedEventArgs) Handles bold4c.Unchecked
        bold4ds.Text = ("")
    End Sub

    Private Sub i1c(sender As Object, e As RoutedEventArgs) Handles italic1c.Checked
        italic1ds.Text = ("italic")
    End Sub

    Private Sub i1uc(sender As Object, e As RoutedEventArgs) Handles italic1c.Unchecked
        italic1ds.Text = ("")
    End Sub

    Private Sub i2c(sender As Object, e As RoutedEventArgs) Handles italic2c.Checked
        italic2ds.Text = ("italic")
    End Sub

    Private Sub i2uc(sender As Object, e As RoutedEventArgs) Handles italic2c.Unchecked
        italic2ds.Text = ("")
    End Sub

    Private Sub i3c(sender As Object, e As RoutedEventArgs) Handles italic3c.Checked
        italic3ds.Text = ("italic")
    End Sub

    Private Sub i3uc(sender As Object, e As RoutedEventArgs) Handles italic3c.Unchecked
        italic3ds.Text = ("")
    End Sub

    Private Sub i4c(sender As Object, e As RoutedEventArgs) Handles italic4c.Checked
        italic4ds.Text = ("italic")
    End Sub

    Private Sub i4uc(sender As Object, e As RoutedEventArgs) Handles italic4c.Unchecked
        italic4ds.Text = ("")
    End Sub

    Private Sub u1c(sender As Object, e As RoutedEventArgs) Handles underline1c.Checked
        If strikethrough1c.IsChecked = True Then
            line1ds.Text = ("underline,strikethrough")
        Else
            line1ds.Text = ("underline")
        End If
    End Sub

    Private Sub u1uc(sender As Object, e As RoutedEventArgs) Handles underline1c.Unchecked
        If strikethrough1c.IsChecked = True Then
            line1ds.Text = ("strikethrough")
        Else
            line1ds.Text = ("")
        End If
    End Sub

    Private Sub u2c(sender As Object, e As RoutedEventArgs) Handles underline2c.Checked
        If strikethrough2c.IsChecked = True Then
            line2ds.Text = ("underline,strikethrough")
        Else
            line2ds.Text = ("underline")
        End If
    End Sub

    Private Sub u2uc(sender As Object, e As RoutedEventArgs) Handles underline2c.Unchecked
        If strikethrough2c.IsChecked = True Then
            line2ds.Text = ("strikethrough")
        Else
            line2ds.Text = ("")
        End If
    End Sub

    Private Sub u3c(sender As Object, e As RoutedEventArgs) Handles underline3c.Checked
        If strikethrough3c.IsChecked = True Then
            line3ds.Text = ("underline,strikethrough")
        Else
            line3ds.Text = ("underline")
        End If
    End Sub

    Private Sub u3uc(sender As Object, e As RoutedEventArgs) Handles underline3c.Unchecked
        If strikethrough3c.IsChecked = True Then
            line3ds.Text = ("strikethrough")
        Else
            line3ds.Text = ("")
        End If
    End Sub

    Private Sub u4c(sender As Object, e As RoutedEventArgs) Handles underline4c.Checked
        If strikethrough4c.IsChecked = True Then
            line4ds.Text = ("underline,strikethrough")
        Else
            line4ds.Text = ("underline")
        End If
    End Sub

    Private Sub u4uc(sender As Object, e As RoutedEventArgs) Handles underline4c.Unchecked
        If strikethrough4c.IsChecked = True Then
            line4ds.Text = ("strikethrough")
        Else
            line4ds.Text = ("")
        End If
    End Sub

    Private Sub st1c(sender As Object, e As RoutedEventArgs) Handles strikethrough1c.Checked
        If underline1c.IsChecked = True Then
            line1ds.Text = ("underline,strikethrough")
        Else
            line1ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st1uc(sender As Object, e As RoutedEventArgs) Handles strikethrough1c.Unchecked
        If underline1c.IsChecked = True Then
            line1ds.Text = ("underline")
        Else
            line1ds.Text = ("")
        End If
    End Sub

    Private Sub st2c(sender As Object, e As RoutedEventArgs) Handles strikethrough2c.Checked
        If underline2c.IsChecked = True Then
            line2ds.Text = ("underline,strikethrough")
        Else
            line2ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st2uc(sender As Object, e As RoutedEventArgs) Handles strikethrough2c.Unchecked
        If underline2c.IsChecked = True Then
            line2ds.Text = ("underline")
        Else
            line2ds.Text = ("")
        End If
    End Sub

    Private Sub st3c(sender As Object, e As RoutedEventArgs) Handles strikethrough3c.Checked
        If underline3c.IsChecked = True Then
            line3ds.Text = ("underline,strikethrough")
        Else
            line3ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st3uc(sender As Object, e As RoutedEventArgs) Handles strikethrough3c.Unchecked
        If underline3c.IsChecked = True Then
            line3ds.Text = ("underline")
        Else
            line3ds.Text = ("")
        End If
    End Sub

    Private Sub st4c(sender As Object, e As RoutedEventArgs) Handles strikethrough4c.Checked
        If underline4c.IsChecked = True Then
            line4ds.Text = ("underline,strikethrough")
        Else
            line4ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st4uc(sender As Object, e As RoutedEventArgs) Handles strikethrough4c.Unchecked
        If underline4c.IsChecked = True Then
            line4ds.Text = ("underline")
        Else
            line4ds.Text = ("")
        End If
    End Sub

    Private Sub signact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready (note: some text effects cannot be displayed in the Preview tab)")
    End Sub

    Private Sub aboutact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready")
    End Sub

    Private Sub link0(sender As Object, e As RoutedEventArgs)
        Dim url As String = "https://github.com/haojiezhe12345/Sign-Designer-for-Minecraft"
        Process.Start(url)
    End Sub

    Private Sub titleact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready")
    End Sub

    Private Sub moreact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready")
    End Sub

    Private Sub Generate1(sender As Object, e As RoutedEventArgs)
        If title.IsChecked = True Then
            output1.Text = headtitle.Text + texttitle.Text + colortitle.Text + colortitlec.Text + boldtitle.Text + boldtitle0.Text + underlinedtitle.Text + underlinetitle0.Text + italictitle.Text + italictitle0.Text + strikethroughtitle.Text + strikethroughtitle0.Text + obfuscatedtitle.Text + obfuscatedtitle0.Text + endtitle.Text
            status0.Text = (" Code generated succesfully!")
        ElseIf subtitle.IsChecked = True Then
            output1.Text = headsubtitle.Text + texttitle.Text + colortitle.Text + colortitlec.Text + boldtitle.Text + boldtitle0.Text + underlinedtitle.Text + underlinetitle0.Text + italictitle.Text + italictitle0.Text + strikethroughtitle.Text + strikethroughtitle0.Text + obfuscatedtitle.Text + obfuscatedtitle0.Text + endtitle.Text
            status0.Text = (" Code generated succesfully!")
        ElseIf actionbar.IsChecked = True Then
            output1.Text = headactionbar.Text + texttitle.Text + colortitle.Text + colortitlec.Text + boldtitle.Text + boldtitle0.Text + underlinedtitle.Text + underlinetitle0.Text + italictitle.Text + italictitle0.Text + strikethroughtitle.Text + strikethroughtitle0.Text + obfuscatedtitle.Text + obfuscatedtitle0.Text + endtitle.Text
            status0.Text = (" Code generated succesfully!")
        Else
            status0.Text = (" Error: Please select a type of Title/SubTitle/ActionBar!")
        End If
    End Sub

    Private Sub Copy1(sender As Object, e As RoutedEventArgs)
        Clipboard.Clear()
        Clipboard.SetText(output1.Text)
        status0.Text = (" Code copied successfully!")
    End Sub
End Class
