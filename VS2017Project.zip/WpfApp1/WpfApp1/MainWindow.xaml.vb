﻿Class MainWindow
    Private Sub Generate0(sender As Object, e As RoutedEventArgs)
        output0.Text = head.Text + ("Text1") + text.Text + text1.Text + color.Text + color1.Text + bold.Text + bold1.Text + italic.Text + italic1.Text + underlined.Text + underline1.Text + strikethrough.Text + strikethrough1.Text + obfuscated.Text + obfuscated1.Text + clickevent.Text + clickevent1.Text + end0.Text + ("Text2") + text.Text + text2.Text + color.Text + color2.Text + bold.Text + bold2.Text + italic.Text + italic2.Text + underlined.Text + underline2.Text + strikethrough.Text + strikethrough2.Text + obfuscated.Text + obfuscated2.Text + clickevent.Text + clickevent2.Text + end0.Text + ("Text3") + text.Text + text3.Text + color.Text + color3.Text + bold.Text + bold3.Text + italic.Text + italic3.Text + underlined.Text + underline3.Text + strikethrough.Text + strikethrough3.Text + obfuscated.Text + obfuscated3.Text + clickevent.Text + clickevent3.Text + end0.Text + ("Text4") + text.Text + text4.Text + color.Text + color4.Text + bold.Text + bold4.Text + italic.Text + italic4.Text + underlined.Text + underline4.Text + strikethrough.Text + strikethrough4.Text + obfuscated.Text + obfuscated4.Text + clickevent.Text + clickevent4.Text + end0.Text + [end].Text
        status0.Text = (" Code generated successfully!")
        copysign.IsEnabled = True
    End Sub

    Private Sub Copy0(sender As Object, e As RoutedEventArgs)
        Clipboard.Clear()
        Clipboard.SetText(output0.Text)
        status0.Text = (" Code copied successfully!")
    End Sub

    Private Sub b1c(sender As Object, e As RoutedEventArgs) Handles bold1c.Checked
        bold1ds.Text = ("bold")
    End Sub

    Private Sub b1uc(sender As Object, e As RoutedEventArgs) Handles bold1c.Unchecked
        bold1ds.Text = ("")
    End Sub

    Private Sub b2c(sender As Object, e As RoutedEventArgs) Handles bold2c.Checked
        bold2ds.Text = ("bold")
    End Sub

    Private Sub b2uc(sender As Object, e As RoutedEventArgs) Handles bold2c.Unchecked
        bold2ds.Text = ("")
    End Sub

    Private Sub b3c(sender As Object, e As RoutedEventArgs) Handles bold3c.Checked
        bold3ds.Text = ("bold")
    End Sub

    Private Sub b3uc(sender As Object, e As RoutedEventArgs) Handles bold3c.Unchecked
        bold3ds.Text = ("")
    End Sub

    Private Sub b4c(sender As Object, e As RoutedEventArgs) Handles bold4c.Checked
        bold4ds.Text = ("bold")
    End Sub

    Private Sub b4uc(sender As Object, e As RoutedEventArgs) Handles bold4c.Unchecked
        bold4ds.Text = ("")
    End Sub

    Private Sub i1c(sender As Object, e As RoutedEventArgs) Handles italic1c.Checked
        italic1ds.Text = ("italic")
    End Sub

    Private Sub i1uc(sender As Object, e As RoutedEventArgs) Handles italic1c.Unchecked
        italic1ds.Text = ("")
    End Sub

    Private Sub i2c(sender As Object, e As RoutedEventArgs) Handles italic2c.Checked
        italic2ds.Text = ("italic")
    End Sub

    Private Sub i2uc(sender As Object, e As RoutedEventArgs) Handles italic2c.Unchecked
        italic2ds.Text = ("")
    End Sub

    Private Sub i3c(sender As Object, e As RoutedEventArgs) Handles italic3c.Checked
        italic3ds.Text = ("italic")
    End Sub

    Private Sub i3uc(sender As Object, e As RoutedEventArgs) Handles italic3c.Unchecked
        italic3ds.Text = ("")
    End Sub

    Private Sub i4c(sender As Object, e As RoutedEventArgs) Handles italic4c.Checked
        italic4ds.Text = ("italic")
    End Sub

    Private Sub i4uc(sender As Object, e As RoutedEventArgs) Handles italic4c.Unchecked
        italic4ds.Text = ("")
    End Sub

    Private Sub u1c(sender As Object, e As RoutedEventArgs) Handles underline1c.Checked
        If strikethrough1c.IsChecked = True Then
            line1ds.Text = ("underline,strikethrough")
        Else
            line1ds.Text = ("underline")
        End If
    End Sub

    Private Sub u1uc(sender As Object, e As RoutedEventArgs) Handles underline1c.Unchecked
        If strikethrough1c.IsChecked = True Then
            line1ds.Text = ("strikethrough")
        Else
            line1ds.Text = ("")
        End If
    End Sub

    Private Sub u2c(sender As Object, e As RoutedEventArgs) Handles underline2c.Checked
        If strikethrough2c.IsChecked = True Then
            line2ds.Text = ("underline,strikethrough")
        Else
            line2ds.Text = ("underline")
        End If
    End Sub

    Private Sub u2uc(sender As Object, e As RoutedEventArgs) Handles underline2c.Unchecked
        If strikethrough2c.IsChecked = True Then
            line2ds.Text = ("strikethrough")
        Else
            line2ds.Text = ("")
        End If
    End Sub

    Private Sub u3c(sender As Object, e As RoutedEventArgs) Handles underline3c.Checked
        If strikethrough3c.IsChecked = True Then
            line3ds.Text = ("underline,strikethrough")
        Else
            line3ds.Text = ("underline")
        End If
    End Sub

    Private Sub u3uc(sender As Object, e As RoutedEventArgs) Handles underline3c.Unchecked
        If strikethrough3c.IsChecked = True Then
            line3ds.Text = ("strikethrough")
        Else
            line3ds.Text = ("")
        End If
    End Sub

    Private Sub u4c(sender As Object, e As RoutedEventArgs) Handles underline4c.Checked
        If strikethrough4c.IsChecked = True Then
            line4ds.Text = ("underline,strikethrough")
        Else
            line4ds.Text = ("underline")
        End If
    End Sub

    Private Sub u4uc(sender As Object, e As RoutedEventArgs) Handles underline4c.Unchecked
        If strikethrough4c.IsChecked = True Then
            line4ds.Text = ("strikethrough")
        Else
            line4ds.Text = ("")
        End If
    End Sub

    Private Sub st1c(sender As Object, e As RoutedEventArgs) Handles strikethrough1c.Checked
        If underline1c.IsChecked = True Then
            line1ds.Text = ("underline,strikethrough")
        Else
            line1ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st1uc(sender As Object, e As RoutedEventArgs) Handles strikethrough1c.Unchecked
        If underline1c.IsChecked = True Then
            line1ds.Text = ("underline")
        Else
            line1ds.Text = ("")
        End If
    End Sub

    Private Sub st2c(sender As Object, e As RoutedEventArgs) Handles strikethrough2c.Checked
        If underline2c.IsChecked = True Then
            line2ds.Text = ("underline,strikethrough")
        Else
            line2ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st2uc(sender As Object, e As RoutedEventArgs) Handles strikethrough2c.Unchecked
        If underline2c.IsChecked = True Then
            line2ds.Text = ("underline")
        Else
            line2ds.Text = ("")
        End If
    End Sub

    Private Sub st3c(sender As Object, e As RoutedEventArgs) Handles strikethrough3c.Checked
        If underline3c.IsChecked = True Then
            line3ds.Text = ("underline,strikethrough")
        Else
            line3ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st3uc(sender As Object, e As RoutedEventArgs) Handles strikethrough3c.Unchecked
        If underline3c.IsChecked = True Then
            line3ds.Text = ("underline")
        Else
            line3ds.Text = ("")
        End If
    End Sub

    Private Sub st4c(sender As Object, e As RoutedEventArgs) Handles strikethrough4c.Checked
        If underline4c.IsChecked = True Then
            line4ds.Text = ("underline,strikethrough")
        Else
            line4ds.Text = ("strikethrough")
        End If
    End Sub

    Private Sub st4uc(sender As Object, e As RoutedEventArgs) Handles strikethrough4c.Unchecked
        If underline4c.IsChecked = True Then
            line4ds.Text = ("underline")
        Else
            line4ds.Text = ("")
        End If
    End Sub

    Private Sub signact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready (obfuscated cannot be displayed in the designer)")
    End Sub

    Private Sub aboutact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready")
    End Sub

    Private Sub link0(sender As Object, e As RoutedEventArgs)
        Dim url As String = "https://github.com/haojiezhe12345/Minecraft_Command_Block_Helper"
        Process.Start(url)
    End Sub

    Private Sub titleact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready (obfuscated cannot be displayed in the designer)")
    End Sub

    Private Sub Generate1(sender As Object, e As RoutedEventArgs)
        If title.IsChecked = True Then
            output1.Text = headtitle.Text + texttitle.Text + colortitle.Text + colortitlec.Text + boldtitle.Text + boldtitle0.Text + underlinedtitle.Text + underlinetitle0.Text + italictitle.Text + italictitle0.Text + strikethroughtitle.Text + strikethroughtitle0.Text + obfuscatedtitle.Text + obfuscatedtitle0.Text + endtitle.Text
            status0.Text = (" Code generated succesfully!")
            copytitle.IsEnabled = True
        ElseIf subtitle.IsChecked = True Then
            output1.Text = headsubtitle.Text + texttitle.Text + colortitle.Text + colortitlec.Text + boldtitle.Text + boldtitle0.Text + underlinedtitle.Text + underlinetitle0.Text + italictitle.Text + italictitle0.Text + strikethroughtitle.Text + strikethroughtitle0.Text + obfuscatedtitle.Text + obfuscatedtitle0.Text + endtitle.Text
            status0.Text = (" Code generated succesfully!")
            copytitle.IsEnabled = True
        ElseIf actionbar.IsChecked = True Then
            output1.Text = headactionbar.Text + texttitle.Text + colortitle.Text + colortitlec.Text + boldtitle.Text + boldtitle0.Text + underlinedtitle.Text + underlinetitle0.Text + italictitle.Text + italictitle0.Text + strikethroughtitle.Text + strikethroughtitle0.Text + obfuscatedtitle.Text + obfuscatedtitle0.Text + endtitle.Text
            status0.Text = (" Code generated succesfully!")
            copytitle.IsEnabled = True
        Else
            status0.Text = (" Error: Please select a type of Title/SubTitle/ActionBar first!")
        End If
    End Sub

    Private Sub Copy1(sender As Object, e As RoutedEventArgs)
        Clipboard.Clear()
        Clipboard.SetText(output1.Text)
        status0.Text = (" Code copied successfully!")
    End Sub

    Private Sub titlec(sender As Object, e As RoutedEventArgs) Handles title.Checked
        titlepre.Visibility = Visibility.Visible
        subtitlepre.Visibility = Visibility.Hidden
        actionbarpre.Visibility = Visibility.Hidden
    End Sub

    Private Sub subtitlec(sender As Object, e As RoutedEventArgs) Handles subtitle.Checked
        titlepre.Visibility = Visibility.Hidden
        subtitlepre.Visibility = Visibility.Visible
        actionbarpre.Visibility = Visibility.Hidden
    End Sub

    Private Sub actionbarc(sender As Object, e As RoutedEventArgs) Handles actionbar.Checked
        titlepre.Visibility = Visibility.Hidden
        subtitlepre.Visibility = Visibility.Hidden
        actionbarpre.Visibility = Visibility.Visible
    End Sub

    Private Sub btitlec(sender As Object, e As RoutedEventArgs) Handles boldtitlec.Checked
        titlepre.FontWeight = FontWeights.Bold
        subtitlepre.FontWeight = FontWeights.Bold
        actionbarpre.FontWeight = FontWeights.Bold
    End Sub

    Private Sub btitleuc(sender As Object, e As RoutedEventArgs) Handles boldtitlec.Unchecked
        titlepre.FontWeight = FontWeights.Normal
        subtitlepre.FontWeight = FontWeights.Normal
        actionbarpre.FontWeight = FontWeights.Normal
    End Sub

    Private Sub ititlec(sender As Object, e As RoutedEventArgs) Handles italictitlec.Checked
        titlepre.FontStyle = FontStyles.Italic
        subtitlepre.FontStyle = FontStyles.Italic
        actionbarpre.FontStyle = FontStyles.Italic
    End Sub

    Private Sub ititleuc(sender As Object, e As RoutedEventArgs) Handles italictitlec.Unchecked
        titlepre.FontStyle = FontStyles.Normal
        subtitlepre.FontStyle = FontStyles.Normal
        actionbarpre.FontStyle = FontStyles.Normal
    End Sub

    Private Sub undrlinetitlec(sender As Object, e As RoutedEventArgs) Handles underlinetitlec.Checked
        If strikethroughtitlec.IsChecked = True Then
            titleulst.Text = ("underline,strikethrough")
        Else
            titleulst.Text = ("underline")
        End If
    End Sub

    Private Sub underlinetitleuc(sender As Object, e As RoutedEventArgs) Handles underlinetitlec.Unchecked
        If strikethroughtitlec.IsChecked = True Then
            titleulst.Text = ("strikethrough")
        Else
            titleulst.Text = ("")
        End If
    End Sub

    Private Sub starkethroughtitlec(sender As Object, e As RoutedEventArgs) Handles strikethroughtitlec.Checked
        If underlinetitlec.IsChecked = True Then
            titleulst.Text = ("underline,strikethrough")
        Else
            titleulst.Text = ("strikethrough")
        End If
    End Sub

    Private Sub strikethroughuc(sender As Object, e As RoutedEventArgs) Handles strikethroughtitlec.Unchecked
        If underlinetitlec.IsChecked = True Then
            titleulst.Text = ("underline")
        Else
            titleulst.Text = ("")
        End If
    End Sub

    Private Sub colorsign1(sender As Object, e As SelectionChangedEventArgs) Handles color1.SelectionChanged
        Select Case color1.SelectedIndex
            Case ("0")
                signpre1.Foreground = Brushes.Black
            Case ("1")
                signpre1.Foreground = Brushes.White
            Case ("2")
                signpre1.Foreground = Brushes.Red
            Case ("3")
                signpre1.Foreground = Brushes.DarkRed
            Case ("4")
                signpre1.Foreground = Brushes.Green
            Case ("5")
                signpre1.Foreground = Brushes.DarkGreen
            Case ("6")
                signpre1.Foreground = Brushes.Blue
            Case ("7")
                signpre1.Foreground = Brushes.DarkBlue
            Case ("8")
                signpre1.Foreground = Brushes.MediumPurple
            Case ("9")
                signpre1.Foreground = Brushes.Aqua
            Case ("10")
                signpre1.Foreground = Brushes.MediumAquamarine
            Case ("11")
                signpre1.Foreground = Brushes.DarkGray
            Case ("12")
                signpre1.Foreground = Brushes.Gray
            Case ("13")
                signpre1.Foreground = Brushes.Purple
            Case ("14")
                signpre1.Foreground = Brushes.Yellow
            Case ("15")
                signpre1.Foreground = Brushes.Gold
        End Select
    End Sub

    Private Sub colorsign2(sender As Object, e As SelectionChangedEventArgs) Handles color2.SelectionChanged
        Select Case color2.SelectedIndex
            Case ("0")
                signpre2.Foreground = Brushes.Black
            Case ("1")
                signpre2.Foreground = Brushes.White
            Case ("2")
                signpre2.Foreground = Brushes.Red
            Case ("3")
                signpre2.Foreground = Brushes.DarkRed
            Case ("4")
                signpre2.Foreground = Brushes.Green
            Case ("5")
                signpre2.Foreground = Brushes.DarkGreen
            Case ("6")
                signpre2.Foreground = Brushes.Blue
            Case ("7")
                signpre2.Foreground = Brushes.DarkBlue
            Case ("8")
                signpre2.Foreground = Brushes.MediumPurple
            Case ("9")
                signpre2.Foreground = Brushes.Aqua
            Case ("10")
                signpre2.Foreground = Brushes.MediumAquamarine
            Case ("11")
                signpre2.Foreground = Brushes.DarkGray
            Case ("12")
                signpre2.Foreground = Brushes.Gray
            Case ("13")
                signpre2.Foreground = Brushes.Purple
            Case ("14")
                signpre2.Foreground = Brushes.Yellow
            Case ("15")
                signpre2.Foreground = Brushes.Gold
        End Select
    End Sub

    Private Sub colorsign3(sender As Object, e As SelectionChangedEventArgs) Handles color3.SelectionChanged
        Select Case color3.SelectedIndex
            Case ("0")
                signpre3.Foreground = Brushes.Black
            Case ("1")
                signpre3.Foreground = Brushes.White
            Case ("2")
                signpre3.Foreground = Brushes.Red
            Case ("3")
                signpre3.Foreground = Brushes.DarkRed
            Case ("4")
                signpre3.Foreground = Brushes.Green
            Case ("5")
                signpre3.Foreground = Brushes.DarkGreen
            Case ("6")
                signpre3.Foreground = Brushes.Blue
            Case ("7")
                signpre3.Foreground = Brushes.DarkBlue
            Case ("8")
                signpre3.Foreground = Brushes.MediumPurple
            Case ("9")
                signpre3.Foreground = Brushes.Aqua
            Case ("10")
                signpre3.Foreground = Brushes.MediumAquamarine
            Case ("11")
                signpre3.Foreground = Brushes.DarkGray
            Case ("12")
                signpre3.Foreground = Brushes.Gray
            Case ("13")
                signpre3.Foreground = Brushes.Purple
            Case ("14")
                signpre3.Foreground = Brushes.Yellow
            Case ("15")
                signpre3.Foreground = Brushes.Gold
        End Select
    End Sub

    Private Sub colorsign4(sender As Object, e As SelectionChangedEventArgs) Handles color4.SelectionChanged
        Select Case color4.SelectedIndex
            Case ("0")
                signpre4.Foreground = Brushes.Black
            Case ("1")
                signpre4.Foreground = Brushes.White
            Case ("2")
                signpre4.Foreground = Brushes.Red
            Case ("3")
                signpre4.Foreground = Brushes.DarkRed
            Case ("4")
                signpre4.Foreground = Brushes.Green
            Case ("5")
                signpre4.Foreground = Brushes.DarkGreen
            Case ("6")
                signpre4.Foreground = Brushes.Blue
            Case ("7")
                signpre4.Foreground = Brushes.DarkBlue
            Case ("8")
                signpre4.Foreground = Brushes.MediumPurple
            Case ("9")
                signpre4.Foreground = Brushes.Aqua
            Case ("10")
                signpre4.Foreground = Brushes.MediumAquamarine
            Case ("11")
                signpre4.Foreground = Brushes.DarkGray
            Case ("12")
                signpre4.Foreground = Brushes.Gray
            Case ("13")
                signpre4.Foreground = Brushes.Purple
            Case ("14")
                signpre4.Foreground = Brushes.Yellow
            Case ("15")
                signpre4.Foreground = Brushes.Gold
        End Select
    End Sub

    Private Sub colortitle0(sender As Object, e As SelectionChangedEventArgs) Handles colortitlec.SelectionChanged
        Select Case colortitlec.SelectedIndex
            Case ("0")
                titlepre.Foreground = Brushes.White
                subtitlepre.Foreground = Brushes.White
                actionbarpre.Foreground = Brushes.White
            Case ("1")
                titlepre.Foreground = Brushes.Black
                subtitlepre.Foreground = Brushes.Black
                actionbarpre.Foreground = Brushes.Black
            Case ("2")
                titlepre.Foreground = Brushes.Red
                subtitlepre.Foreground = Brushes.Red
                actionbarpre.Foreground = Brushes.Red
            Case ("3")
                titlepre.Foreground = Brushes.DarkRed
                subtitlepre.Foreground = Brushes.DarkRed
                actionbarpre.Foreground = Brushes.DarkRed
            Case ("4")
                titlepre.Foreground = Brushes.Green
                subtitlepre.Foreground = Brushes.Green
                actionbarpre.Foreground = Brushes.Green
            Case ("5")
                titlepre.Foreground = Brushes.DarkGreen
                subtitlepre.Foreground = Brushes.DarkGreen
                actionbarpre.Foreground = Brushes.DarkGreen
            Case ("6")
                titlepre.Foreground = Brushes.Blue
                subtitlepre.Foreground = Brushes.Blue
                actionbarpre.Foreground = Brushes.Blue
            Case ("7")
                titlepre.Foreground = Brushes.DarkBlue
                subtitlepre.Foreground = Brushes.DarkBlue
                actionbarpre.Foreground = Brushes.DarkBlue
            Case ("8")
                titlepre.Foreground = Brushes.MediumPurple
                subtitlepre.Foreground = Brushes.MediumPurple
                actionbarpre.Foreground = Brushes.MediumPurple
            Case ("9")
                titlepre.Foreground = Brushes.Aqua
                subtitlepre.Foreground = Brushes.Aqua
                actionbarpre.Foreground = Brushes.Aqua
            Case ("10")
                titlepre.Foreground = Brushes.MediumAquamarine
                subtitlepre.Foreground = Brushes.MediumAquamarine
                actionbarpre.Foreground = Brushes.MediumAquamarine
            Case ("11")
                titlepre.Foreground = Brushes.DarkGray
                subtitlepre.Foreground = Brushes.DarkGray
                actionbarpre.Foreground = Brushes.DarkGray
            Case ("12")
                titlepre.Foreground = Brushes.Gray
                subtitlepre.Foreground = Brushes.Gray
                actionbarpre.Foreground = Brushes.Gray
            Case ("13")
                titlepre.Foreground = Brushes.Purple
                subtitlepre.Foreground = Brushes.Purple
                actionbarpre.Foreground = Brushes.Purple
            Case ("14")
                titlepre.Foreground = Brushes.Yellow
                subtitlepre.Foreground = Brushes.Yellow
                actionbarpre.Foreground = Brushes.Yellow
            Case ("15")
                titlepre.Foreground = Brushes.Gold
                subtitlepre.Foreground = Brushes.Gold
                actionbarpre.Foreground = Brushes.Gold
        End Select
    End Sub

    Private Sub tellrawact(sender As Object, e As RoutedEventArgs)
        status0.Text = (" Ready (preview can be just display the original text, no effects)")
    End Sub

    Private Sub showdbgtool0(sender As Object, e As RoutedEventArgs)
        If showdbgtool.Content = ("Show Debug Tools") Then
            MainWindow0.Height = 800
            showdbgtool.Content = ("Hide Debug Tools")
        Else
            MainWindow0.Height = 323
            showdbgtool.Content = ("Show Debug Tools")
        End If
    End Sub

    Private Sub tellrawmsg0(sender As Object, e As RoutedEventArgs)
        msg0.Visibility = Visibility.Hidden
        tellrawgrid0.Visibility = Visibility.Visible
    End Sub

    Private Sub Generate2(sender As Object, e As RoutedEventArgs)
        codetellraw0.SelectedIndex = 0
        output2.Text = (tellrawhead.Text + codetellraw1.Text)
        If codecount0.Text > 1 Then
            Do
                codetellraw0.SelectedIndex = (codetellraw0.SelectedIndex + 1)
                output2.Text = (output2.Text + codetellraw1.Text)
            Loop While codetellraw0.SelectedIndex < (codecount0.Text - 1)
        End If
        output2.Text = (output2.Text + tellrawend.Text)
        status0.Text = (" Code generated succesfully!")
        copytellraw.IsEnabled = True
    End Sub

    Private Sub Copy2(sender As Object, e As RoutedEventArgs) Handles copytellraw.Click
        Clipboard.Clear()
        Clipboard.SetText(output2.Text)
        status0.Text = (" Code copied successfully!")
    End Sub

    Private Sub removetellraw0(sender As Object, e As RoutedEventArgs)
        texttellraw0.SelectedIndex = codetellraw0.SelectedIndex
        texttellraw0.Items.Remove(texttellraw0.SelectedItem)
        codetellraw0.Items.Remove(codetellraw0.SelectedItem)
        codecount0.Text = (codecount0.Text - 1)
        codetellraw0.SelectedIndex = (codecount0.Text - 1)
        texttellraw0.SelectedIndex = -1
        status0.Text = (" Item removed successfully!")
    End Sub

    Private Sub addtellraw0(sender As Object, e As RoutedEventArgs)
        texttellraw0.Items.Add(tellrawtext0.Text)
        If tellrawclickactc.SelectedIndex = 0 And tellrawhveventactc.SelectedIndex = 0 Then
            codetellraw0.Items.Add(tellrawtext.Text + tellrawtext0.Text + tellrawtextend.Text + tellrawcolor.Text + tellrawcolor0.Text + tellrawbold.Text + tellrawbold0.Text + tellrawunderlined.Text + tellrawunderline0.Text + tellrawitalic.Text + tellrawitalic0.Text + tellrawstrikethrough.Text + tellrawstrikethrough0.Text + tellrawobfuscated.Text + tellrawobfuscated0.Text + tellrawmainend.Text)
        End If
        If tellrawclickactc.SelectedIndex <> 0 And tellrawhveventactc.SelectedIndex = 0 Then
            codetellraw0.Items.Add(tellrawtext.Text + tellrawtext0.Text + tellrawtextend.Text + tellrawcolor.Text + tellrawcolor0.Text + tellrawbold.Text + tellrawbold0.Text + tellrawunderlined.Text + tellrawunderline0.Text + tellrawitalic.Text + tellrawitalic0.Text + tellrawstrikethrough.Text + tellrawstrikethrough0.Text + tellrawobfuscated.Text + tellrawobfuscated0.Text + tellrawclickact.Text + tellrawclickactc.Text + tellrawclickvalue.Text + tellrawclickvalue0.Text + tellrawclickend.Text + tellrawmainend.Text)
        End If
        If tellrawclickactc.SelectedIndex = 0 And tellrawhveventactc.SelectedIndex <> 0 Then
            codetellraw0.Items.Add(tellrawtext.Text + tellrawtext0.Text + tellrawtextend.Text + tellrawcolor.Text + tellrawcolor0.Text + tellrawbold.Text + tellrawbold0.Text + tellrawunderlined.Text + tellrawunderline0.Text + tellrawitalic.Text + tellrawitalic0.Text + tellrawstrikethrough.Text + tellrawstrikethrough0.Text + tellrawobfuscated.Text + tellrawobfuscated0.Text + tellrawhveventact.Text + tellrawhveventactc.Text + tellrawhveventtextvalue.Text + tellrawhveventtextvaluec.Text + tellrawhveventcolor.Text + tellrawmainwithhvenentend.Text + tellrawmainend.Text)
        End If
        If tellrawclickactc.SelectedIndex <> 0 And tellrawhveventactc.SelectedIndex <> 0 Then
            codetellraw0.Items.Add(tellrawtext.Text + tellrawtext0.Text + tellrawtextend.Text + tellrawcolor.Text + tellrawcolor0.Text + tellrawbold.Text + tellrawbold0.Text + tellrawunderlined.Text + tellrawunderline0.Text + tellrawitalic.Text + tellrawitalic0.Text + tellrawstrikethrough.Text + tellrawstrikethrough0.Text + tellrawobfuscated.Text + tellrawobfuscated0.Text + tellrawclickact.Text + tellrawclickactc.Text + tellrawclickvalue.Text + tellrawclickvalue0.Text + tellrawclickend.Text + tellrawhveventact.Text + tellrawhveventactc.Text + tellrawhveventtextvalue.Text + tellrawhveventtextvaluec.Text + tellrawhveventcolor.Text + tellrawmainwithhvenentend.Text + tellrawmainend.Text)
        End If
        codecount0.Text = (codecount0.Text + 1)
        codetellraw0.SelectedIndex = (codecount0.Text - 1)
        texttellraw0.SelectedIndex = -1
        status0.Text = (" Item added successfully!")
    End Sub
End Class
