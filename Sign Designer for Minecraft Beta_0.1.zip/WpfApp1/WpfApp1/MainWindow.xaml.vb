﻿Class MainWindow
    Private Sub Generate0(sender As Object, e As RoutedEventArgs)
        output0.Text = head.Text + ("Text1") + text.Text + text1.Text + color.Text + color1.Text + bold.Text + bold1.Text + italic.Text + italic1.Text + underlined.Text + underline1.Text + strikethrough.Text + strikethrough1.Text + obfuscated.Text + obfuscated1.Text + clickevent.Text + clickevent1.Text + end0.Text + ("Text2") + text.Text + text2.Text + color.Text + color2.Text + bold.Text + bold2.Text + italic.Text + italic2.Text + underlined.Text + underline2.Text + strikethrough.Text + strikethrough2.Text + obfuscated.Text + obfuscated2.Text + clickevent.Text + clickevent2.Text + end0.Text + ("Text3") + text.Text + text3.Text + color.Text + color3.Text + bold.Text + bold3.Text + italic.Text + italic3.Text + underlined.Text + underline3.Text + strikethrough.Text + strikethrough3.Text + obfuscated.Text + obfuscated3.Text + clickevent.Text + clickevent3.Text + end0.Text + ("Text4") + text.Text + text4.Text + color.Text + color4.Text + bold.Text + bold4.Text + italic.Text + italic4.Text + underlined.Text + underline4.Text + strikethrough.Text + strikethrough4.Text + obfuscated.Text + obfuscated4.Text + clickevent.Text + clickevent4.Text + end0.Text + [end].Text
        status0.Text = (" Code generated successfully!")
    End Sub

    Private Sub Copy0(sender As Object, e As RoutedEventArgs)
        status0.Text = (" This operation is not avaliable now")
    End Sub
End Class
